# Resume Project - Atif Alam (Batch 1)

This is a simple responsive resume built using **HTML and CSS**.

## Sections
- Introduction
- Objective
- Qualification
- Skills
- Hobbies

## Features
- Fully responsive layout
- Beginner-friendly clean code
- Uses rem and em units for scalability

## How to View
1. Clone the repository:
   ```bash
   git clone https://github.com/YourUsername/AtifAlam_Batch1.git
   ```
2. Open `index.html` in a browser.
